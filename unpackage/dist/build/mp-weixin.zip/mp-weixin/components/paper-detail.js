(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/paper-detail"],{2146:function(t,e,n){"use strict";n.r(e);var u=n("6b15"),r=n.n(u);for(var a in u)"default"!==a&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a},"3e52":function(t,e,n){"use strict";n.r(e);var u=n("5c21"),r=n("2146");for(var a in r)"default"!==a&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("8919");var c,f=n("f0c5"),i=Object(f["a"])(r["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],c);e["default"]=i.exports},"5c21":function(t,e,n){"use strict";var u,r=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}))},"6b15":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={data:function(){return{}},props:{paperName:{type:String,default:""},questionNum:{type:Number,default:0},testTime:{type:String,default:""},fullMarks:{type:Number,default:0},testmodel:{type:String,default:"L"}},methods:{}};e.default=u},8919:function(t,e,n){"use strict";var u=n("9c6e"),r=n.n(u);r.a},"9c6e":function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/paper-detail-create-component',
    {
        'components/paper-detail-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("3e52"))
        })
    },
    [['components/paper-detail-create-component']]
]);
